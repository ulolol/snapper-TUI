# Snapper TUI

An opinionated, interactive textual user interface for managing **snapper** snapshots. The application mirrors `snapper list` but pairs it with used-space totals, a responsive layout, and clickable actions so you can preview rollout or deletion commands without leaving the terminal.

## Features
- Lists each snapshot along with type, dates, cleanup strategy, description, user metadata, and per-snapshot disk usage (when available).
- Click table headers to sort the list by number, date, type, size, or any other visible column.
- Select a snapshot to expose restore, delete, and status commands in the right-hand action panel.
- Bottom-right summary keeps `total space used` and `current space free` in view while the action panel stays context-aware.

## Installation
1. Clone the repository and change into it:
   ```sh
   git clone https://github.com/ulolol/snapper-TUI.git
   cd snapper-TUI
   ```
2. Use an isolated environment (recommended for systems with PEP 668 enforced):
   ```sh
   python -m venv .venv
   source .venv/bin/activate
   pip install .
   ```
3. Alternatively, install directly:
   ```sh
   pip install snapper-tui
   ```

## Usage
- Launch the UI with the provided entry point:
  ```sh
  snapper-tui
  ```
- Running `snapper-tui` without root privileges will still work, but you must configure `snapper` so the current user can access the `.snapshots` directory or run the TUI itself under `sudo` (e.g., `sudo snapper-tui`).
- Click on any header to toggle sorting. Snapshots are sorted by number by default.
- Highlight a row to see descriptive snapshot metadata, plus three actionable commands (restore, delete, status). Use the buttons to mirror your intended CLI command; executing the action still requires you to run the command manually or paste it into a shell.
- The bottom-right summary shows the current aggregate snapshot usage and disk free space for `SNAPPER_TUI_ROOT_PATH` (default `/`). Set that environment variable before launching the UI to change which mount point is monitored.

## Project Structure
- `pyproject.toml` defines the package, dependencies, and the `snapper-tui` console script.
- `snapper_tui/data.py` wraps `snapper --jsonout list` and parses the snapshot records.
- `snapper_tui/app.py` builds the Textual UI, including the sortable table, detail panel, and action buttons.
- `snapper_tui/utils.py` contains size formatting helpers and free-space lookups.
- `AILog.md` tracks research steps and decisions (updated in tandem with work).

## Development Notes
- Textual 0.50+ is required; the project pins `textual>=0.50` in `pyproject.toml`.
- Python 3.11+ is required for modern type annotations and language features.
- The CLI relies on the system `snapper` command. Ensure the same user can list snapshots from the configured volume or run the UI with enough permissions.

## Troubleshooting
- If the UI reports it cannot read snapshots, verify you can run `snapper --jsonout list` from the same shell and that the `.snapshots` directory is readable.
- The action buttons only display commands; actual restore/delete/status steps must be run in a terminal to avoid unwanted changes inside the UI.

## License
MIT © Snapper TUI Contributors

## Contact
Maintained by the Snapper TUI community via [https://github.com/ulolol/snapper-TUI](https://github.com/ulolol/snapper-TUI).
